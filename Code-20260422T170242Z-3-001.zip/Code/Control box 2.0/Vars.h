// This file is for all globle varibles and paramiders 

#include <Arduino.h>
#ifndef Vars_h
#define Vars_h

//display grafix
const uint8_t F[] = {0b01110001}; //F
const uint8_t C[] = {0b00111001}; //C
const uint8_t P[] = {0b01110011}; //P
const uint8_t StOP[] = { 0b01101101, 0b01111000, 0b00111111, 0b01110011 };  //StoP
const uint8_t tEnP[] = { 0b00000000, 0b01110110, 0b01011100, 0b01111000 };  //Hot
const uint8_t AcEt[] = { 0b01110111, 0b00111001, 0b01111001, 0b01111000 };  //AcEt
const uint8_t SEC[] = { 0b00000000, 0b01101101, 0b01111001, 0b00111001 };  //SEC
const uint8_t HEAt[] = { 0b01110110, 0b01111001, 0b01110111, 0b01111000 };  //HEAt


//encoder varebles 
short EncodeCLK = 3, EncodeDT = 4, EncodeSW = 5; //encoder pins
short lastState, currentState;

short SegCLK2 = 6, SegDIO2 = 7;    //7 seggment display pins
short SegCLK = 18, SegDIO = 19;    //7 seggment display pins
short button = 2, fan1 = 9, fan2 = 10, ultrasonic = 11, heaterPin = 10; //other pins

//globle vars
int encodePositon = 0;
int screen = 0;
int pause = 1250;
int count = 10;
int countDown;
unsigned long time = 0;
int target = 0;


#endif