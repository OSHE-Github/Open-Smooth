
// Author: Austin Deegan
// Date: 10/6/25
// Discription: controls a heater with bang bang controls

#include "Heater.h"
#include "Thermister.h"
#include <Arduino.h>

//vars
static double target = 10;
static int pin2;
static NTC_100k heat(0);

//inishalise. Input <heater pin> <NTC_100k object>
RelayHeater::RelayHeater(int pin, NTC_100k thermister){ 
  pinMode(pin, OUTPUT);
  pin2 = pin;
  heat = thermister;
}

// Sets the target tempacher. 0 to disable. 
//Must constently call run or will over heat.
//Input <temp in F or C> <True if Farenhight> 
double RelayHeater::setTemp(double Temp, bool Faren){
  double old = Temp;
  target = Temp;
  if(Faren) target = (target - 32) * 5/9;
  return old;
}

// Shuts off the heater. No longer need to call run 
void RelayHeater::kill(){
  target = 0;
  digitalWrite(pin2,LOW);
}

//disables heater until next run comand
void RelayHeater::pause(){
  digitalWrite(pin2,LOW);
}

//Returns the tempacher of the heater.
//Input <True if want in Farenhight> 
double RelayHeater::read(bool Faren){
  return heat.read(Faren);
}

//returns the curent target of the heater
//Input <True if want in Farenhight> 
double RelayHeater::curentSet(bool Faren){
  if(Faren && target!=0) return ((target * 9.0/5)+32); // converted to farenhight
  return target;
}

// MUST constntly call to run the heater
//curently bad and untested implemented
void RelayHeater::run(){
  if(heat.readNow(false)/10<target && target>0) digitalWrite(pin2,HIGH);
  else digitalWrite(pin2,LOW);
}



