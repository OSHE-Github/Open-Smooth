#include <TM1637Display.h>//librarys that you have to install
#include "Thermister.h"
#include "Vars.h"
#include "Heater.h"


TM1637Display display(SegCLK, SegDIO);
TM1637Display display2(SegCLK2, SegDIO2);
NTC_100k tempSence(A0);
RelayHeater heater(heaterPin,tempSence);


void setup() {

  pinMode(EncodeCLK,INPUT);
  pinMode(EncodeDT,INPUT);
  pinMode(EncodeSW,INPUT);
  pinMode(button,INPUT_PULLUP);
  pinMode(fan1,OUTPUT);
  //pinMode(fan2,OUTPUT);
  pinMode(ultrasonic,OUTPUT);

  //Serial.begin(9600);
  
  display.setBrightness(7);
  display.clear();
  display2.setBrightness(7);
  display2.clear();

  attachInterrupt(digitalPinToInterrupt(EncodeCLK), encode, CHANGE);
  attachInterrupt(digitalPinToInterrupt(button), stop, LOW);

    target = heater.curentSet(true);
}

void loop() {
  update();

  if(encodePositon < 0) encodePositon = 3;
  if(encodePositon > 3) encodePositon = 0;
  screen = encodePositon;
  disp(encodePositon);

  if(digitalRead(EncodeSW)==0){
    heater.pause();
    delay(1000);

    // run count sown if held for 2 sec
    if(digitalRead(EncodeSW)==0){
    
      digitalWrite(ultrasonic,HIGH);
      display.clear();
      countDown = count;
      while(count>0){
        disp(1);
        delay(1000);
        count--;
        update();
      }
      digitalWrite(ultrasonic,LOW);
      count = countDown;
    }

    //sets the time
    else if (screen == 1){
      display.clear();
      encodePositon = count;
      while(digitalRead(EncodeSW)==1){
        if(encodePositon < 1) encodePositon = 1;
        count = encodePositon;
        disp(screen);
      }
    }

    //sets the heater
    else if (screen == 3){
      display.clear();
      encodePositon = target;
      while(digitalRead(EncodeSW)==1){
        if(encodePositon < 0) encodePositon = 0;
        target = encodePositon;
        heater.setTemp(target, true);
        disp(screen);
      }
    }
  encodePositon = screen;
  delay(1000);
  display.clear();
  }

}


//updates when encoder is used
void encode(){
  currentState = digitalRead(EncodeCLK);
  if (currentState != lastState && currentState == 1) {
    if (digitalRead(EncodeDT) != digitalRead(EncodeCLK)) encodePositon++;
    else encodePositon--;
  }
  lastState = currentState;
  time = millis()-pause;
  screen = 4;
  
}

//update heater and senser data
void update(){
  heater.run();
}

//estop. all proseses stoped exspt fans
void stop(){

  heater.kill();
  digitalWrite(ultrasonic,LOW);
  digitalWrite(fan1,HIGH);
  //digitalWrite(fan2,HIGH);
  display.setSegments(StOP);
  while(true){
    disp(5);
  }

}

//all of the displays 
void disp(int in){
  
  switch (in){
    case 0: //temp
      display2.setSegments(tEnP);//says hot
      display.showNumberDecEx(tempSence.read(true), 0b01000000, false, 3, 0); //shows temp in F
      display.setSegments(F, 1, 3);
      break;
    case 1: //time
        display2.setSegments(SEC);//says SEC
        display.showNumberDecEx(count, 0b01000000, true, 4, 0);   //displays seconds
      break;
    case 2://acetone
        display2.setSegments(AcEt);//say acetone
        display.setSegments(P, 1, 3);//displays acetone prsent
        display.showNumberDecEx(0, 0b01000000, true, 3, 0);
      break;
    case 3://heater
      display2.setSegments(HEAt);//say acetone
      display.showNumberDecEx(heater.read(true)/10, 0b01000000, true, 2, 0);   //displays temp  
      display.showNumberDecEx(heater.curentSet(true), 0b01000000, false, 2, 2);   //displays target 
      break;

    //used by estop
    case 5://acetone and heater temp
        display2.showNumberDecEx(0, 0b01000000, true, 2, 0);
        display2.showNumberDecEx(tempSence.readNow(true)/10, 0b01000000, true, 2, 2);   //displays temp  
      break;

  }


}



