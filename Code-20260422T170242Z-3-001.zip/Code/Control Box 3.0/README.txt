Control Box 3.0

Here are the instructions on how to use the controller.

NOTE: The sensor needs time to warm up to be accurate. 

The knob will let you scroll through menus and change settings.

A short press of the knob will allow you to change the settings of the current menu.

A long press will run the acetone cycle. While in a cycle a long press will stop the cycle.

Menus:

	Hot:
		Displays the current temperature in Fahrenheit.
		
	SEC: 
		How many seconds to run the acetone cycle for.

		The first press will allow you to change min
		Press again to change the seconds
		Press to save

	AcEt: 
		Displays current : target acetone. 
		
		Will only run during acetone cycle.
		
		Press to change the value
		Press to save
		
	HEAt:
		Displays current : target of heater
		
		ALWAYS RUNNING unless target is 0
		
		If target is above 50 fan will be on.
		
		Press to change the value
		Press to save
		
	FAnH:
		Displays current heater fan oporation.
		
		Press to toggle on/off.
		Will run if heater target is above 50F.
		
	FAnF:
		Displays current filter fan oporation.
		
		Press to toggle on/off.
		
	FAn:
		Displays current chamber fan oporation.
		
		Press to toggle on/off.
	