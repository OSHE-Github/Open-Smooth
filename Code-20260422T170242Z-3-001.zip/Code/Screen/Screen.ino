
//incled parting file
#include "Parse.h"

//buzzer on pin 19
int buzzer = 19;

//define touch screen and tft
TouchScreen ts = TouchScreen(XP, YP, XM, YM, 300);
Elegoo_TFTLCD tft(LCD_CS, LCD_CD, LCD_WR, LCD_RD, LCD_RESET);

//Setup code
void setup() {

// EEPROM.write(1, 45);
// EEPROM.write(2, 30);
// EEPROM.write(3, 15);
// EEPROM.write(4, 15);
// EEPROM.write(5, 10);
// EEPROM.write(6, 5);



  //start serial at 9600 baud rate
  Serial.begin(9600);
  
  //start tft and set roation
  tft.begin(0x9341);
  tft.setRotation(1);

  //pinsetup for touchscreen and buzzer
  pinMode(13, OUTPUT);
  pinMode(19, OUTPUT);

  //inshalise SD card and report if failed
  if (!SD.begin(SD_CS)) {
    Serial.println(F("SD failed!"));
    parse("Text(SD ERROR,50,100,4,0)", tft);
    return;
  }

  //remove old files 
  SD.remove(update);
  SD.remove(bFile);

  //run the starting file
  sd("begin.txt",tft);
}


//the runing body of the code
void loop() {
  
  //save screen touch to p
  digitalWrite(13, HIGH);
  TSPoint p = ts.getPoint();
  digitalWrite(13, LOW);
  pinMode(LCD_CS, OUTPUT);
  pinMode(LCD_CD, OUTPUT);

  //check to see if screen was touched
  if (p.z > 10) {
    Serial.println("touch");
    int temp = p.x;
    //convert the touch to quredents on screen
    p.x=map(p.y,930,40,0,320);
    p.y=map(temp,900,160,0,240);
    Serial.println(p.x);
    Serial.println(p.y);

    //beep the buzzer
    for (int i = 0; i < 100; i++){
      digitalWrite(buzzer, HIGH);
      delayMicroseconds(500);
      digitalWrite(buzzer, LOW);
      delayMicroseconds(500);
    }
    //extra delay to prevent double press
    delay(50);
    
    //check to see if a button was pressesd
    for(int i = 0; i < bCount; i++){
      if(p.x>buttons[i][0] && p.x<buttons[i][2] && p.y>buttons[i][1] && p.y<buttons[i][3]){
        //if button was pressed open file and print line 
        file = SD.open(bFile);
        //serch through the file until corect line is found
        for(int j = 0; j<=i;j++){
          for(int k = 0; k < 40; k++){
            Fileline[k] = file.read();
            if (Fileline[k]==10){
              Fileline[k] = 0;
              break;
            } 
          }
        }
        //close the file 
        file.close();
        delay(5);
        Serial.println(Fileline);
        //run the file line
        parse(Fileline,tft);
        break;
      }
    }


  }


  // delay(1000);
  // parse("run(update.txt)", tft);
  // x+=10;
}
