
//include varible file and a config file
#include "var.h"
#include "config.h"

//include librarys
#include <SD.h>
#include <SPI.h>
#include <Elegoo_GFX.h>    // Core graphics library
#include <Elegoo_TFTLCD.h> // Hardware-specific library
#include <TouchScreen.h>

//create a file object
File file;

//function prototypes
void sd(const char* in, Elegoo_TFTLCD tft);
void parse(char* in, Elegoo_TFTLCD tft);
//String special(String in);
int index(const char* in, char c, int start, int size);
void subchar(char* out, const char* in, int start, int end);
unsigned int toInt(const char* in, int start, int end);
bool equal(const char* in, const char* test, int size);

//reads out a file and sends it to be parsed
void read(File file, Elegoo_TFTLCD tft){
  while(file.available()){
    
    for(int i = 0; i < FILELINE; i++){
      Fileline[i] = file.read();
      if (Fileline[i]==10){
        Fileline[i] = 0;
        for(int j = i; j < FILELINE; j++){
          Fileline[j] = 0;
        }
        break;
      } 
    }
    parse(Fileline, tft);
  }
}

//parses and runs input char arrays
void parse( char* in, Elegoo_TFTLCD tft){

  //looks for ( and saves it 
  int next = index(in,'(',0,FILELINE)+1;
  int end;

  //seporat out the comand inculding the first (
  subchar(comand, in, 0, next);

  //seporats out the numbers from the comand
  for(int i = 0; i<7; i++){
    end = index(in,',',next+1,FILELINE);
    //if no , look for the end
    if (end == -1) {
      end = index(in,')',next,FILELINE);
      input[i] = toInt(in,next,end);
      break;
    }
    input[i] = toInt(in,next,end);
    next = end + 1;
  }

  //start of pasrsing 

  //new button(comand,x,y,x2,y2)
  if(equal(comand,"Button",6)){
    
    //the curent file is closes to save memory
    filePosition = file.position();
    strcpy(fileName,file.name());
    file.close();
    delay(5);
    //saves button to file and array
    file = SD.open(bFile, FILE_WRITE);
    buttons [bCount][0] = input[1];
    buttons [bCount][1] = input[2];
    buttons [bCount][2] = input[3];
    buttons [bCount][3] = input[4];
    bCount++;
    char f[FILELINE];
    subchar( f, in, 7, index( in, ',', 0, 40));
    file.println(f);
    //close the buuton file 
    file.close();
    delay(5);

    //reopen and return to position of curent file
    file = SD.open(fileName, FILE_WRITE);
    file.seek(filePosition);
  }
  //drawas a Rectangle(x,y,x2,y2,color)
  else if(equal(comand,"Rectangle", 9)){
    tft.fillRect(input[0],input[1],input[2]-input[0],input[3]-input[1],input[4]);
  }
  //drawas a Circle(x,y,r,color)
  else if(equal(comand,"Circle", 6)){
    tft.fillCircle(input[0],input[1],input[2],input[3]);
  }
  //drawas a Round corner Rectangle (x,y,x2,y2,r,color)
  else if(equal(comand,"RoundRect", 9)){
    tft.fillRoundRect(input[0],input[1],input[2]-input[0],input[3]-input[1],input[4],input[5]);
  }
  //draws a line(x,y,x2,y2,color)
  else if(equal(comand,"Line", 4)){
    tft.drawLine(input[0],input[1],input[2],input[3],input[4]);
  }
  //clears screen(color), buttons, and update text 
  else if(equal(comand,"Clear", 5)){
    tft.fillScreen(input[0]);
    bCount = 0;
    SD.remove(update);
    SD.remove(bFile);
  }
  //prints text(text,x,y,thichness,color)
  else if(equal(comand,"Text(", 5)){
    tft.setCursor(input[1],input[2]);
    tft.setTextColor(input[4]);
    tft.setTextSize(input[3]);
    //parses out the text from the fileline
    char temp[40];
    for(int i = 0; i<40; i++) temp[i] = 0;
    subchar(temp, in, 5, index( in, ',', 0, FILELINE));
    special(temp,temp);
    tft.println(temp);
  }
//   else if(equal(comand,"UpdateText", 11)){
//     filePosition = file.position();
//     strcpy(fileName,file.name());
//     file.close();
//     delay(5);
//     Serial.print("text ");
//     Serial.println(file = SD.open(update, FILE_WRITE));
//     file.print("Rectangle(");
//     String coma = ",";
//     String end = ")";
//     String out =  input[1] + coma + input[2] + coma + (input[1]+input[3]*6*input[4])  + coma + (input[2]+input[3]*8) + coma + input[5] + end;
//     file.println(out);

//     file.print("Text(");
//     char f[40];
//     subchar( f, in, 11, index( in, ',', 0, 40));
//     file.print(f);
//     out = coma + input[1] + coma + input[2] + coma + input[3] + coma + input[6] + end;
//     file.println(out);

//     file.close();
//     delay(5);
    
// Serial.print("restaet OK: ");
//      Serial.println(SD.begin(SD_CS));
//     file = SD.open(fileName, FILE_WRITE);
//     //Serial.println(file.seek(filePosition));
//     file.seek(filePosition);
// Serial.print("Reopen OK: ");
// Serial.println(file);
// Serial.print("Seek OK: ");
// Serial.println(file.seek(filePosition));
// Serial.print("Position: ");
// Serial.println(file.position());


//  }
  //sets the screen ratation(0-3)
  else if(equal(comand,"Rotation", 8)){
    tft.setRotation(input[0]);
  }
  //runs a file. old file will be closed and not reopended
  else if(equal(comand,"Run", 3)){
    char f[11];
    subchar( f, in, 4, index( in, ')', 4, 40));
    sd( f, tft);
  }
  else if(equal(comand,"Serial", 6)){
    char temp[40];
    subchar(temp, in, 5, index( in, ',', 0, FILELINE));
    Serial.println(temp);
  }
  else if(equal(comand,"Var", 3)){
    char temp[40];
    subchar(temp, in, 5, index( in, ',', 0, FILELINE));
    Serial.println(temp);
  }
}

//opens a file then sends it to be read
void sd( const char* in, Elegoo_TFTLCD tft) {//fix
  file = SD.open(in);
  read(file, tft);
  file.close();
}


