#include <EEPROM.h>


//this file is the methods that allow you to use a char array as a string


//finds the index of a given char in a char array. if not found returns -1
int index(const char* in, char c, int start, int size){
  if(start<0)return -1;
  for(; start<size; start++){
    if(in[start]==c) return start;
  }
  return -1;
}

//fills out with a subset of in given the start and end indexse
void subchar(char* out, const char* in, int start, int end){
  if(start<0 || end<0 ){
    out[0] = 0;
    return;
  }
  for(int i = 0; i+start<end; i++){
    out[i]=in[i+start];
  }
  out[end-start] = 0;
}

//parses a char array to an int from the start and end index.
unsigned int toInt(const char* in, int start, int end){
  if(start<0 || end<0 )return 0;
  unsigned int out = 0;
  for(int i = 0; i+start<end; i++){
    out = out*10;
    out += in[i+start]-48;
  }
  return out;
}

//checks to see if two char arrays are equal until the size given
bool equal(const char* in, const char* test, int size){
  for(int i = 0; i <size; i++){
    if(in[i]!=test[i]) return 0;
  }
  return 1;
}

//turns a int to a char array
void intToChar(char* out, int in) {
    int i = 0;
    if (in == 0) {
        out[i++] = '0';
        out[i] = 0;
        return;
    }
    //temporary buffer for reversed digits
    char temp[10];
    int t = 0;
    while (in > 0) {
        temp[t++] = (in % 10) + '0';
        in /= 10;
    }
    //reverse into output
    for (int j = 0; j < t; j++) {
        out[j] = temp[t - j - 1];
    }
    out[t] = 0;
}



