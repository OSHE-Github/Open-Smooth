//https://rgbcolorpicker.com/565

//this file allows for chars to be used simaler to strings
#include "char.h"

void special(char* out, const char* in){

  if(equal(in,"EEPROM",6)){
    Serial.println(EEPROM.read(toInt(in,6,index( in, 0, 0, FILELINE))));
    intToChar(out, EEPROM.read(toInt(in,6,index( in, 0, 0, FILELINE))));
  }
  else if(equal(in,"X",1)){
    if(x>999) out = (char*) (x/1000);
    else out = (char*)x;
  }
  else if(equal(in,"Y",1)){
    if(x>999) out = "PPM";
    else out = "PPB";

  }

  out = in;
}


void Var(char* in, int value){



}

