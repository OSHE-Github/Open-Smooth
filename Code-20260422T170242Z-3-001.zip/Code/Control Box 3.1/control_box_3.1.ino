#include <TM1637Display.h>//librarys that you have to install
#include "Thermister.h"
#include "Vars.h"
#include "Heater.h"
#include "Acetone.h"

TM1637Display display(SegCLK, SegDIO);
TM1637Display display2(SegCLK2, SegDIO2);
NTC_100k tempSence(A0);
RelayHeater heater(heaterPin,fan1,tempSence);
bomb acetone(ultrasonic,aceA,aceD,fanHeater);

void setup() {

  pinMode(EncodeCLK,INPUT);
  pinMode(EncodeDT,INPUT);
  pinMode(EncodeSW,INPUT);
  pinMode(button,INPUT_PULLUP);
  pinMode(encloser,INPUT_PULLUP);
  pinMode(fan2,OUTPUT);
  pinMode(ultrasonic,OUTPUT);

  //Serial.begin(9600);
  
  display.setBrightness(7);
  display.clear();
  display2.setBrightness(7);
  display2.clear();

  attachInterrupt(digitalPinToInterrupt(EncodeCLK), encode, CHANGE);
  attachInterrupt(digitalPinToInterrupt(button), stop, LOW);

    target = heater.curentSet(true);
}

void loop() {
  update(false);

  if(encodePositon < 0) encodePositon = 6;
  if(encodePositon > 6) encodePositon = 0;
  screen = encodePositon;
  disp(encodePositon);

  if(digitalRead(EncodeSW)==0){
    heater.pause();
    delay(1000);

    // run count sown if held for 1 sec
    if(digitalRead(EncodeSW)==0){
    
      display.clear();
      countDown = count;
      while(digitalRead(EncodeSW)==0) disp(9);
      while(count>0){
        if(count%100>60) count -= 40;
        
        disp(9);
        delay(1000);
        if(digitalRead(EncodeSW)==0) break;
        count--;
        update(true);
      }
      count = countDown;
    }

    //sets the time
    else if (screen == 1){
      display.clear();
      encodePositon = 0;
      while(digitalRead(EncodeSW)==1){
        if(count < 1) count = 1;
        count += encodePositon*100;
        encodePositon = 0;
        disp(screen);
      }
      delay(1000);
      display.clear();
      encodePositon = 0;
      while(digitalRead(EncodeSW)==1){
        if(count < 1) count = 1;
        count += encodePositon;
        if(count%100 >= 60 && encodePositon == 1) count += 40;
        if(count%100 >= 60 && encodePositon == -1) count -= 40;
        encodePositon = 0;
        disp(screen);
      }
      screen = 1;
    }
    
    // set the acetoon present 
    else if (screen == 2){
      display.clear();
      encodePositon = present;
      while(digitalRead(EncodeSW)==1){
        if(encodePositon < 0) encodePositon = 0;
        present = encodePositon;
        acetone.setAcetone(present);
        disp(screen);
      }
      screen = 2;
    }

    //sets the heater
    else if (screen == 3){
      display.clear();
      encodePositon = target;
      while(digitalRead(EncodeSW)==1){
        if(encodePositon < 0) encodePositon = 0;
        if(encodePositon > 99) encodePositon = 99;
        target = encodePositon;
        heater.setTemp(target, true);
        disp(3);
      }
      screen = 3;
    }

    //Set Heaterfan
    else if (screen == 4){
      if(heater.curentFan()) heater.runFan(false);
      else heater.runFan(true);
      if(heater.curentFan()) display.setSegments(on);
      else display.setSegments(oFF);
      screen = 4;
    }

    //set fanf
    else if (screen == 5){
      if(acetone.getFilter()) acetone.runFilter(false);
      else acetone.runFilter(true);
      if(acetone.getFilter()) display.setSegments(on);
      else display.setSegments(oFF);
      screen = 5;
    }

    //set fan
    else if (screen == 6){
      if(fanP2) fanP2 = false;
      else fanP2 = true;
      if(fanP2) display.setSegments(on);
      else display.setSegments(oFF);
      digitalWrite(fan2,fanP2);
      screen = 6;
    }
  disp(screen);
  encodePositon = screen;
  delay(1000);
  display.clear();
  }

}


//updates when encoder is used
void encode(){
  currentState = digitalRead(EncodeCLK);
  if (currentState != lastState && currentState == 1) {
    if (digitalRead(EncodeDT) != digitalRead(EncodeCLK)) encodePositon++;
    else encodePositon--;
  }
  lastState = currentState;
  time = millis()-pause;
  screen = 4;
  
}

//update heater and senser data
void update(bool ace){
  if(digitalRead(encloser)==1){
    heater.run();
    acetone.run(ace);
  }
  else{
    heater.pause();
    acetone.pause();
  }
  if(heater.read(farenhight)/10>=heatMax) stop();
  digitalWrite(fan2,fanP2);
}

//estop. all proseses stoped exspt fans
void stop(){

  heater.kill();
  acetone.kill();
  digitalWrite(ultrasonic,LOW);
  
  digitalWrite(fan2,HIGH);
  
  
  while(true){


    disp(10);
    if(up) display.setSegments(StOP);
    else display.clear();
    if(!up && blink < 0) up = true;
    if(up && blink > 10) up = false;
    if(up) blink++;
    else blink--;
      

  }

}

//all of the displays 
void disp(int in){
  
  switch (in){
    case 0: //temp
      display2.setSegments(tEnP);//says hot
      display.showNumberDecEx(tempSence.read(farenhight), 0b01000000, false, 3, 0); //shows temp in F
      if(farenhight) display.setSegments(F, 1, 3);
      else display.setSegments(C, 1, 3);
      break;
    case 1: //time
        display2.setSegments(SEC);//says SEC
        display.showNumberDecEx(count, 0b01000000, true, 4, 0);   //displays seconds
      break;
    case 2://acetone
        display2.setSegments(AcEt);//say acetone
      display.showNumberDecEx(acetone.getAcetone(), 0b01000000, true, 2, 0);   //displays acetone present  
      display.showNumberDecEx(acetone.getPresent(), 0b01000000, false, 2, 2);   //displays target 
      break;
    case 3://heater
      display2.setSegments(HEAt);//say acetone
      display.showNumberDecEx(heater.read(farenhight)/10, 0b01000000, true, 2, 0);   //displays temp  
      display.showNumberDecEx(heater.curentSet(farenhight), 0b01000000, false, 2, 2);   //displays target 
      break;

    //used by estop
    case 10://acetone and heater temp
        display2.showNumberDecEx(acetone.getAcetone(), 0b01000000, true, 2, 0);
        display2.showNumberDecEx(tempSence.readNow(farenhight)/10, 0b01000000, true, 2, 2);   //displays temp  
      break;
    case 9://acetone and heater temp
      display2.showNumberDecEx(acetone.getAcetone(), 0b01000000, true, 2, 0);   //displays acetone present  
      display2.showNumberDecEx(acetone.getPresent(), 0b01000000, false, 2, 2);   //displays target  
      display.showNumberDecEx(count, 0b01000000, true, 4, 0);   //displays seconds
      break;

    case 4://fanHeater
        display2.setSegments(FAn_);
        display2.setSegments(H, 1, 3);//H
        if(heater.curentFan()) display.setSegments(on);
        else display.setSegments(oFF);
      break;
    case 5://fanF
        display2.setSegments(FAn_,3,0);
        display2.setSegments(F, 1, 3);//F
        if(acetone.getFilter()) display.setSegments(on);
        else display.setSegments(oFF);
      break;
    case 6://fan
        display2.setSegments(FAn_,3,0);
        display2.setSegments(Z, 1, 3);//F
        if(fanP2) display.setSegments(on);
        else display.setSegments(oFF);
      break;

  }


}



