#include <TM1637Display.h>//librarys that you have to install
#include "Thermister.h"


const uint8_t F[] = {0b01110001};
const uint8_t C[] = {0b00111001};
const uint8_t P[] = {0b01110011};
const uint8_t StOP[] = { 0b01101101, 0b01111000, 0b00111111, 0b01110011 };  //StoP
const uint8_t tEnP[] = { 0b00000000, 0b01110110, 0b01011100, 0b01111000 };  //Hot
const uint8_t AcEt[] = { 0b01110111, 0b00111001, 0b01111001, 0b01111000 };  //AcEt
const uint8_t SEC[] = { 0b00000000, 0b01101101, 0b01111001, 0b00111001 };  //SEC

//encoder varebles 
short EncodeCLK = 3, EncodeDT = 4, EncodeSW = 5; //encoder pins
short lastState, currentState;

short SegCLK = 6, SegDIO = 7;    //7 seggment display pins
short button = 2;
short fan1 = 9, fan2 = 10, ultrasonic = 11;


int encodePositon = 10;
int screen = 0;
int pause = 1250;
int count = 10;
unsigned long time = 0;



TM1637Display display(SegCLK, SegDIO);
NTC_10k tempSence(A0);

void setup() {
  // put your setup code here, to run once:

  pinMode(EncodeCLK,INPUT);
  pinMode(EncodeDT,INPUT);
  pinMode(EncodeSW,INPUT);
  pinMode(button,INPUT_PULLUP);
  pinMode(fan1,OUTPUT);
  pinMode(fan2,OUTPUT);
  pinMode(ultrasonic,OUTPUT);

  
  display.setBrightness(3);
  display.clear();

  attachInterrupt(digitalPinToInterrupt(EncodeCLK), encode, CHANGE);
  attachInterrupt(digitalPinToInterrupt(button), stop, LOW);
}

void loop() {
  
  if(time + pause < millis()){
    time = millis();
    screen++;
    if(screen>8) screen = 0;
  }
  disp(screen);

  if(digitalRead(EncodeSW)==0){
    
    digitalWrite(ultrasonic,HIGH);
    display.clear();
    while(count>0){
      disp(4);
      delay(1000);
      count--;
    }
    digitalWrite(ultrasonic,LOW);
  }
}



void encode(){
  currentState = digitalRead(EncodeCLK);
  if (currentState != lastState && currentState == 1) {
    if (digitalRead(EncodeDT) != digitalRead(EncodeCLK)) encodePositon++;
    else encodePositon--;
  }
  lastState = currentState;
  time = millis()-pause;
  screen = 4;
  if(encodePositon < 1) encodePositon = 1;
  count = encodePositon;
}



void stop(){

  digitalWrite(ultrasonic,LOW);
  digitalWrite(fan1,HIGH);
  digitalWrite(fan2,HIGH);
  display.setSegments(StOP);
  while(true);

}


void disp(int in){

  
  switch (in){
    case 0:
      display.setSegments(tEnP);
      break;
    case 1:
    case 2:
      display.showNumberDecEx(tempSence.read(true), 0b00000000, false, 3, 0);
      display.setSegments(F, 1, 3);
      break;
    case 3:
      display.setSegments(SEC);
      break;
    case 4:
    case 5:
      display.showNumberDecEx(count, 0b01000000, true, 4, 0);      
      break;
    case 6:
      display.setSegments(AcEt);
      break;
    case 7:
    case 8:
      display.setSegments(P, 1, 3);
      display.showNumberDecEx(0, 0b01000000, true, 3, 0);
      
      break;

  }


}
