
// Refrence: https://www.instructables.com/Temperature-Sensor-Using-Thermistor-With-Arduino-U/
// Author: Austin Deegan
// Date: 9/18/25
// Discription: Outputs the tempacher with and analog input
#include "Thermister.h"
#include <Arduino.h>

int timeDelay = 3000; // how long between each mesherment
double out = 0;
unsigned long time2 = 0;
int pin2;

NTC_10k::NTC_10k(int pin){
  pinMode(pin,INPUT); //inishalie thimister pin
  pin2 = pin;
}


double NTC_10k::read(bool Faren){ // input alalog read and true for farenhight

  double temp; // alot of fun math
  temp = analogRead(A0) * (5.0 / 1023.0);
  temp = (100000 * temp) / (5.0 - temp);  // Assuming 100k series resistor
  temp = (1.0 / ( (1.0 / 298.15) + (1.0 / 3950.0) * log(temp / 100000))) - 273.15;


  if(time2 + timeDelay < millis()){ // a delay in how fast meshrments are taken.
    if(Faren) out = ((temp* 9.0/5)+32); // converted to farenhight
    else out = temp;
    time2 = millis();
  }

  return out;
}