// This file is for all globle varibles and paramiders 

#include <Arduino.h>
#ifndef Vars_h
#define Vars_h

//display grafix
const uint8_t F[] = {0b01110001}; //F
const uint8_t C[] = {0b00111001}; //C
const uint8_t P[] = {0b01110011}; //P
const uint8_t H[] = {0b01110110}; //H
const uint8_t Z[] = {0b00000000}; //H
const uint8_t StOP[] = { 0b01101101, 0b01111000, 0b00111111, 0b01110011 };  //StoP
const uint8_t tEnP[] = { 0b00000000, 0b01110110, 0b01011100, 0b01111000 };  //Hot
const uint8_t AcEt[] = { 0b01110111, 0b00111001, 0b01111001, 0b01111000 };  //AcEt
const uint8_t SEC[] = { 0b00000000, 0b01101101, 0b01111001, 0b00111001 };  //SEC
const uint8_t HEAt[] = { 0b01110110, 0b01111001, 0b01110111, 0b01111000 };  //HEAt
const uint8_t FAn_[] = { 0b01110001, 0b01110111, 0b01010100 };  //FAn
const uint8_t oFF[] = { 0b00000000, 0b00111111, 0b01110001, 0b01110001 };  //oFF
const uint8_t on[] = { 0b00000000, 0b00111111, 0b01010100, 0b00000000 };  //on
const uint8_t LID[] = { 0b00111000, 0b00110000, 0b01011110, 0b00000000 };  //LId
const uint8_t OPEN[] = { 0b00111111, 0b01110011, 0b01111001, 0b01010100 };  //OPEn

//encoder varebles 
short EncodeCLK = 3, EncodeDT = 4, EncodeSW = 5; //encoder pins
short lastState, currentState;

short SegCLK2 = 6, SegDIO2 = 7;    //7 seggment display pins
short SegCLK = 18, SegDIO = 19;    //7 seggment display pins
short aceA = A1, aceD = 16;
short thmist = A0;
short button = 2, fanHeater = 8, fan1 = 11, fan2 = 12, ultrasonic = 10, heaterPin = 9, encloser = 13;//other pins
int heatMax = 100;
bool fanP1 = false, fanP2 = false;

//globle vars
int encodePositon = 0;
int screen = 0;
int pause = 1250;
int count = 10;
int count2 = 0;
int countDown;
unsigned long time = 0;
int target = 0, present = 0;
bool farenhight = false;
int blink = 0;
bool up = true;

#endif